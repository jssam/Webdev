let inputArr=process.argv.slice(2);
console.log("Input",inputArr);